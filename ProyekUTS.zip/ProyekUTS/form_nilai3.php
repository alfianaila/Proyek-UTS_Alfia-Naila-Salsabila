<?php
include_once 'header.php';
include_once 'sidebar.php';
?>
<div class="content-wrapper">
<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                    <div class="container card">
<div class="col-12 bg-light pt-3">
<h6>Sistem Penilaian</h6>
</div>
    <h4><center>Form Nilai Siswa</center></h4>
    <hr>
    <br/>
    <div class="container">
        <form class="form-horizontal mt-3" method="POST" action="form_nilai.php">
            <div class="form-group row">
                <label for="text" class="col-4 col-form-label">Nama Lengkap</label> 
                <div class="col-8">
                <input id="text" name="nama" placeholder="Nama Lengkap" type="text" class="form-control" size="30">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-4 col-form-label" for="select">Mata Kuliah</label> 
                <div class="col-8">
                <select name="matkul" class="custom-select">
                    <option selected>Mata Kuliah</option>
                    <option value="DDP">Dasar Dasar Pemrograman</option>
                    <option value="BDI">Basis Data I</option>
                    <option value="PEMWEB">Pemrograman Web</option>
                </select>
                </div>
            </div>
            <div class="form-group row">
                <label for="nilai_uts" class="col-4 col-form-label">Nilai UTS</label> 
                <div class="col-8">
                <input id="nilai_uts" name="nilai_uts" placeholder="Nilai UTS" type="text" class="form-control">
                </div>
            </div> 
            <div class="form-group row">
                <label for="nilai_uas" class="col-4 col-form-label">Nilai UAS</label> 
                <div class="col-8">
                <input id="nilai_uas" name="nilai_uas" placeholder="Nilai UAS" type="text" class="form-control">
                </div>
            </div> 
            <div class="form-group row">
                <label for="nilai_tugas" class="col-4 col-form-label">Nilai Tugas/Praktikum</label> 
                <div class="col-8">
                <input id="nilai_tugas" name="nilai_tugas" placeholder="Nilai Tugas" type="text" class="form-control">
                </div>
            </div> 
            <div class="form-group row">
                <div class="offset-4 col-8">
                <button name="proses" type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </div>
            <div class="col-12 bg-light pt-3">
            </div>
            </form>
            </div>
        <hr>
        <br/>
        <?php
include_once 'libfungsi.php';
if (isset($_POST['proses'])) {
$proses= $_POST['proses'];
$nama_siswa = $_POST['nama'];
$mata_kuliah = $_POST['matkul'];
$nilai_uts = $_POST['nilai_uts'];
$nilai_uas = $_POST['nilai_uas'];
$nilai_tugas = $_POST['nilai_tugas'];


echo '<br/>Nama Lengkap : '.$nama_siswa;
echo '<br/>Mata Kuliah : '.$mata_kuliah;
echo '<br/>Nilai UTS : '.$nilai_uts;
echo '<br/>Nilai UAS : '.$nilai_uas;
echo '<br/>Nilai Tugas Praktikum : '.$nilai_tugas;


$result = persentase($nilai_uts, $nilai_uas, $nilai_tugas);
$grade_nilai = grade_nilai($result);

echo '<br>Nilai Akhir : '.$result;
echo '<br>Status : '.kelulusan($result);
echo '<br>Grade Nilai : '.grade_nilai ($result);
echo '<br>Predikat Nilai : '.predikat_nilai($grade_nilai);
} else {
    echo 'Form Belum Diisi';
}
?>


</div>
</div>
</main>

<?php
include_once 'footer.php';
?>
</div>
</div>